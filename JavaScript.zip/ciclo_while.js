/* While    
    while es empleado para ejecutar un bloque de código mientras una condición sea verdadera.
    */
    let contador = 0;
    while(contador<=5){
         console.log(contador);
         contador++;
    }
    //Ejercicio rápido
    /*
    Listar los nùmero impares del 1 al 10 utilizando while. 
    */
    let contador2 = 1;      
    while(contador2<=10){
        console.log(contador2);
        contador2+=2;
    }
/*
for (inicialización; condición; incremento/decremento){
    //bloque de código
}
*/
 for(let i=0; i<=5; i++){ //i++ es igual a i=i+1
        console.log(i);
    }

    //Ejercicio rápido
    /*
    Crear un nuevo script que muestre los números pares del 1 al 10.
    */
    for(let i=2; i<=10; i+=2){
       
            console.log(i);
        }
    
    
    